#!/bin/bash
cd "`dirname $0`"/sqldeveloper/bin && bash sqldeveloper $*
